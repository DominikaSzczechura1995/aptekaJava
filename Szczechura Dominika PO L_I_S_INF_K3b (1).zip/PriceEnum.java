package Apteka;

public enum PriceEnum {

    NIEZNANA_ILOŚĆ,
    MAŁO,
    OPTYMALNIE,
    DUŻO,


}
