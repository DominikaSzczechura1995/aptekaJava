package Apteka;

public interface Interfejsable {
    // metody abstrakcyjne które będą musiały być zaimplementowane we wszystkich klasach implementujących interfejs Interfejsable:
    String toString_klient();

    String toString_admin();

    String toString_delivery();

}
